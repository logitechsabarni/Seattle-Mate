import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { MessageSquare, ThumbsUp, Plus, MapPin, Calendar } from 'lucide-react';
import { communityPostsAPI, postCommentsAPI } from '@/services/database';
import type { CommunityPost } from '@/types/database';
import { useToast } from '@/hooks/use-toast';
import { formatDistanceToNow } from 'date-fns';

export default function Community() {
  const [posts, setPosts] = useState<CommunityPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { toast } = useToast();

  const [newPost, setNewPost] = useState({
    city: '',
    title: '',
    content: '',
    category: 'general' as 'roommate' | 'event' | 'query' | 'general',
    is_anonymous: false
  });

  useEffect(() => {
    loadPosts();
  }, [selectedCity, selectedCategory]);

  const loadPosts = async () => {
    try {
      setLoading(true);
      const data = await communityPostsAPI.getAll(selectedCity || undefined, selectedCategory || undefined);
      setPosts(data);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load posts. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePost = async () => {
    if (!newPost.city || !newPost.title || !newPost.content) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive'
      });
      return;
    }

    try {
      await communityPostsAPI.create(newPost);
      toast({
        title: 'Success',
        description: 'Post created successfully'
      });
      setIsDialogOpen(false);
      setNewPost({
        city: '',
        title: '',
        content: '',
        category: 'general',
        is_anonymous: false
      });
      loadPosts();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create post. Please try again.',
        variant: 'destructive'
      });
    }
  };

  const handleUpvote = async (postId: string) => {
    try {
      await communityPostsAPI.upvote(postId);
      loadPosts();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to upvote. Please try again.',
        variant: 'destructive'
      });
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'roommate': return 'bg-primary/10 text-primary';
      case 'event': return 'bg-secondary/10 text-secondary';
      case 'query': return 'bg-accent/10 text-accent';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const filteredPosts = posts.filter(post => {
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return post.title.toLowerCase().includes(query) || post.content.toLowerCase().includes(query);
    }
    return true;
  });

  return (
    <div className="min-h-screen bg-background pb-20 xl:pb-8">
      <div className="bg-success text-success-foreground py-8 px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">💬 Community</h1>
          <p className="opacity-90">Connect with fellow newcomers and locals</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="mb-6 space-y-4">
          <div className="flex flex-col xl:flex-row gap-4">
            <Input
              placeholder="Search posts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1"
            />
            <div className="flex gap-2">
              <Select value={selectedCity} onValueChange={setSelectedCity}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Cities" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Cities</SelectItem>
                  <SelectItem value="Mumbai">Mumbai</SelectItem>
                  <SelectItem value="Bangalore">Bangalore</SelectItem>
                  <SelectItem value="Delhi">Delhi</SelectItem>
                  <SelectItem value="Chennai">Chennai</SelectItem>
                  <SelectItem value="Pune">Pune</SelectItem>
                  <SelectItem value="Hyderabad">Hyderabad</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="roommate">Roommate</SelectItem>
                  <SelectItem value="event">Event</SelectItem>
                  <SelectItem value="query">Query</SelectItem>
                  <SelectItem value="general">General</SelectItem>
                </SelectContent>
              </Select>

              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    New Post
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Create New Post</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">City *</label>
                      <Input
                        placeholder="Enter city name"
                        value={newPost.city}
                        onChange={(e) => setNewPost({ ...newPost, city: e.target.value })}
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Category *</label>
                      <Select value={newPost.category} onValueChange={(value: any) => setNewPost({ ...newPost, category: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="general">General</SelectItem>
                          <SelectItem value="roommate">Roommate</SelectItem>
                          <SelectItem value="event">Event</SelectItem>
                          <SelectItem value="query">Query</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Title *</label>
                      <Input
                        placeholder="Enter post title"
                        value={newPost.title}
                        onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium mb-2 block">Content *</label>
                      <Textarea
                        placeholder="Write your post content..."
                        value={newPost.content}
                        onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                        rows={6}
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="anonymous"
                        checked={newPost.is_anonymous}
                        onChange={(e) => setNewPost({ ...newPost, is_anonymous: e.target.checked })}
                        className="rounded"
                      />
                      <label htmlFor="anonymous" className="text-sm">Post anonymously</label>
                    </div>

                    <Button onClick={handleCreatePost} className="w-full">
                      Create Post
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-6 w-3/4 mb-2 bg-muted" />
                  <Skeleton className="h-4 w-full mb-2 bg-muted" />
                  <Skeleton className="h-4 w-2/3 bg-muted" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredPosts.map((post) => (
              <Card key={post.id} className="hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={getCategoryColor(post.category || 'general')}>
                          {post.category || 'general'}
                        </Badge>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <MapPin className="w-3 h-3 mr-1" />
                          <span>{post.city}</span>
                        </div>
                      </div>
                      <h3 className="text-lg font-semibold mb-2">{post.title}</h3>
                      <p className="text-muted-foreground mb-3">{post.content}</p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          <span>{formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}</span>
                        </div>
                        {post.is_anonymous && (
                          <Badge variant="outline">Anonymous</Badge>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 pt-3 border-t border-border">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleUpvote(post.id)}
                      className="flex items-center"
                    >
                      <ThumbsUp className="w-4 h-4 mr-1" />
                      <span>{post.upvotes}</span>
                    </Button>
                    <Button variant="ghost" size="sm" className="flex items-center">
                      <MessageSquare className="w-4 h-4 mr-1" />
                      <span>Reply</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {!loading && filteredPosts.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <MessageSquare className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-muted-foreground mb-4">No posts found</p>
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Create First Post
              </Button>
            </CardContent>
          </Card>
        )}

        <Card className="mt-6 bg-gradient-secondary">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold mb-2 text-black">🤝 Community Guidelines</h3>
            <ul className="space-y-2 text-sm text-black/80">
              <li>• Be respectful and kind to all community members</li>
              <li>• Share accurate information and helpful advice</li>
              <li>• Protect your privacy - don't share sensitive personal details</li>
              <li>• Report inappropriate content or behavior</li>
              <li>• Help newcomers feel welcome and supported</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
