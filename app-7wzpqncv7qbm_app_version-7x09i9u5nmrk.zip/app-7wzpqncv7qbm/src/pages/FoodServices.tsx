import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Phone, Star, IndianRupee, Search, CheckCircle2, XCircle } from 'lucide-react';
import { tiffinServicesAPI } from '@/services/database';
import type { TiffinService } from '@/types/database';
import { useToast } from '@/hooks/use-toast';

export default function FoodServices() {
  const [services, setServices] = useState<TiffinService[]>([]);
  const [filteredServices, setFilteredServices] = useState<TiffinService[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    loadServices();
  }, []);

  useEffect(() => {
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const filtered = services.filter(service =>
        service.name.toLowerCase().includes(query) ||
        service.city.toLowerCase().includes(query) ||
        service.cuisine_types?.some(c => c.toLowerCase().includes(query))
      );
      setFilteredServices(filtered);
    } else {
      setFilteredServices(services);
    }
  }, [searchQuery, services]);

  const loadServices = async () => {
    try {
      setLoading(true);
      const data = await tiffinServicesAPI.getAll();
      setServices(data);
      setFilteredServices(data);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load food services. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20 xl:pb-8">
      <div className="bg-secondary text-secondary-foreground py-8 px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">🍱 Tiffin & Food Services</h1>
          <p className="opacity-90">Discover delicious home-cooked meals and tiffin services</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input
              placeholder="Search by name, city, or cuisine..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        <div className="mb-4">
          <p className="text-sm text-muted-foreground">
            Found {filteredServices.length} service{filteredServices.length !== 1 ? 's' : ''}
          </p>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <Skeleton className="h-6 w-3/4 mb-2 bg-muted" />
                  <Skeleton className="h-4 w-full mb-2 bg-muted" />
                  <Skeleton className="h-4 w-2/3 mb-4 bg-muted" />
                  <Skeleton className="h-10 w-full bg-muted" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredServices.map((service) => (
              <Card key={service.id} className="hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-lg mb-1">{service.name}</h3>
                      <p className="text-sm text-muted-foreground">{service.city}, {service.state}</p>
                    </div>
                    <div className="flex items-center text-sm">
                      <Star className="w-4 h-4 text-accent fill-accent mr-1" />
                      <span>{service.rating.toFixed(1)}</span>
                    </div>
                  </div>

                  {service.description && (
                    <p className="text-sm text-muted-foreground mb-4">
                      {service.description}
                    </p>
                  )}

                  {service.cuisine_types && service.cuisine_types.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {service.cuisine_types.map((cuisine, idx) => (
                        <Badge key={idx} variant="secondary">{cuisine}</Badge>
                      ))}
                    </div>
                  )}

                  {service.meal_types && service.meal_types.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-4">
                      {service.meal_types.map((meal, idx) => (
                        <Badge key={idx} variant="outline">{meal}</Badge>
                      ))}
                    </div>
                  )}

                  <div className="space-y-2 mb-4">
                    {service.price_per_meal && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Per Meal</span>
                        <div className="flex items-center font-semibold text-primary">
                          <IndianRupee className="w-4 h-4" />
                          <span>{service.price_per_meal}</span>
                        </div>
                      </div>
                    )}
                    {service.monthly_plan_price && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Monthly Plan</span>
                        <div className="flex items-center font-semibold text-primary">
                          <IndianRupee className="w-4 h-4" />
                          <span>{service.monthly_plan_price}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center text-sm">
                      {service.is_available ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-success mr-1" />
                          <span className="text-success">Available</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-4 h-4 text-destructive mr-1" />
                          <span className="text-destructive">Not Available</span>
                        </>
                      )}
                    </div>
                  </div>

                  {service.contact_phone && (
                    <Button className="w-full" asChild>
                      <a href={`tel:${service.contact_phone}`}>
                        <Phone className="w-4 h-4 mr-2" />
                        Contact
                      </a>
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {!loading && filteredServices.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <p className="text-muted-foreground mb-4">No food services found</p>
              <Button onClick={() => setSearchQuery('')}>Clear Search</Button>
            </CardContent>
          </Card>
        )}

        <Card className="mt-8 bg-gradient-secondary text-secondary-foreground">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold mb-2">💡 Pro Tip</h3>
            <p className="text-sm opacity-90">
              Try monthly plans for better value! Most services offer discounts on monthly subscriptions compared to daily meals.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
