import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Building2, UtensilsCrossed, Bus, Languages, MessageSquare, Shield, Sparkles } from 'lucide-react';

const features = [
  {
    icon: Building2,
    title: 'PG & Hostel Finder',
    description: 'Find your perfect accommodation across India',
    path: '/pgs',
    color: 'text-primary'
  },
  {
    icon: UtensilsCrossed,
    title: 'Food Services',
    description: 'Discover tiffin and meal services',
    path: '/food',
    color: 'text-secondary'
  },
  {
    icon: Bus,
    title: 'Transport Guide',
    description: 'Navigate your new city with ease',
    path: '/transport',
    color: 'text-accent'
  },
  {
    icon: Languages,
    title: 'Language Assistant',
    description: 'Break language barriers instantly',
    path: '/language',
    color: 'text-info'
  },
  {
    icon: MessageSquare,
    title: 'Community',
    description: 'Connect with fellow newcomers',
    path: '/community',
    color: 'text-success'
  },
  {
    icon: Shield,
    title: 'Safety Tools',
    description: 'Stay safe with emergency features',
    path: '/safety',
    color: 'text-warning'
  }
];

export default function Home() {
  return (
    <div className="min-h-screen bg-background pb-20 xl:pb-8">
      <div className="bg-gradient-primary text-primary-foreground py-12 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center mb-4">
            <Sparkles className="w-8 h-8 mr-2" />
            <h1 className="text-4xl font-bold">SettleMate</h1>
          </div>
          <p className="text-lg opacity-90 mb-6">
            Your trusted companion for settling in any Indian city
          </p>
          <p className="text-sm opacity-80 max-w-2xl mx-auto">
            Whether you're a student, job-seeker, or professional, we've got everything you need to make your transition smooth and stress-free 🏠
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold mb-2">Welcome! 👋</h2>
          <p className="text-muted-foreground">
            Explore our features designed to help you settle comfortably in your new city
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 mb-8">
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <Link key={feature.path} to={feature.path}>
                <Card className="h-full hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className={`p-3 rounded-lg bg-muted ${feature.color}`}>
                        <Icon className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1">{feature.title}</h3>
                        <p className="text-sm text-muted-foreground">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>

        <Card className="bg-gradient-secondary">
          <CardContent className="p-6">
            <div className="flex flex-col xl:flex-row items-center justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold mb-2 text-black">Need personalized help? 🤖</h3>
                <p className="text-sm text-black/80">
                  Chat with our AI assistant for instant guidance and recommendations
                </p>
              </div>
              <Link to="/chat">
                <Button variant="secondary" size="lg" className="bg-card text-card-foreground hover:bg-card/90">
                  Start Chat
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-primary mb-2">1000+</div>
              <p className="text-sm text-muted-foreground">PG Listings</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-secondary mb-2">50+</div>
              <p className="text-sm text-muted-foreground">Cities Covered</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-accent mb-2">24/7</div>
              <p className="text-sm text-muted-foreground">AI Support</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
