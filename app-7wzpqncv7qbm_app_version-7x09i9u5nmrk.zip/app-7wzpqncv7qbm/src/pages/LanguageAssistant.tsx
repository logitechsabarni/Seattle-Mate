import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Languages, Volume2, Mic, Copy, ArrowRightLeft } from 'lucide-react';
import { translationAPI, textToSpeechAPI, speechToTextAPI } from '@/services/api';
import { translationHistoryAPI } from '@/services/database';
import { useToast } from '@/hooks/use-toast';

const indianLanguages = [
  { code: 'hi', name: 'Hindi' },
  { code: 'bn', name: 'Bengali' },
  { code: 'te', name: 'Telugu' },
  { code: 'mr', name: 'Marathi' },
  { code: 'ta', name: 'Tamil' },
  { code: 'gu', name: 'Gujarati' },
  { code: 'kn', name: 'Kannada' },
  { code: 'ml', name: 'Malayalam' },
  { code: 'pa', name: 'Punjabi' },
  { code: 'or', name: 'Odia' },
  { code: 'as', name: 'Assamese' },
  { code: 'ur', name: 'Urdu' },
  { code: 'en', name: 'English' }
];

const commonPhrases = [
  { context: 'Rent Negotiation', phrases: [
    { en: 'What is the monthly rent?', hi: 'महीने का किराया कितना है?' },
    { en: 'Is electricity included?', hi: 'क्या बिजली शामिल है?' },
    { en: 'Can I see the room?', hi: 'क्या मैं कमरा देख सकता हूं?' },
    { en: 'When can I move in?', hi: 'मैं कब अंदर जा सकता हूं?' }
  ]},
  { context: 'Market Shopping', phrases: [
    { en: 'How much does this cost?', hi: 'यह कितने का है?' },
    { en: 'Can you give a discount?', hi: 'क्या आप छूट दे सकते हैं?' },
    { en: 'Do you have a smaller size?', hi: 'क्या आपके पास छोटा साइज है?' },
    { en: 'I will take this', hi: 'मैं यह ले लूंगा' }
  ]},
  { context: 'Travel', phrases: [
    { en: 'Where is the bus stop?', hi: 'बस स्टॉप कहां है?' },
    { en: 'How much is the fare?', hi: 'किराया कितना है?' },
    { en: 'Does this go to...?', hi: 'क्या यह... जाता है?' },
    { en: 'Please stop here', hi: 'कृपया यहां रुकें' }
  ]},
  { context: 'Daily Conversations', phrases: [
    { en: 'Hello, how are you?', hi: 'नमस्ते, आप कैसे हैं?' },
    { en: 'Thank you very much', hi: 'बहुत धन्यवाद' },
    { en: 'I don\'t understand', hi: 'मुझे समझ नहीं आया' },
    { en: 'Can you help me?', hi: 'क्या आप मेरी मदद कर सकते हैं?' }
  ]}
];

export default function LanguageAssistant() {
  const [sourceText, setSourceText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [sourceLang, setSourceLang] = useState('en');
  const [targetLang, setTargetLang] = useState('hi');
  const [isTranslating, setIsTranslating] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { toast } = useToast();

  const handleTranslate = async () => {
    if (!sourceText.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter text to translate',
        variant: 'destructive'
      });
      return;
    }

    try {
      setIsTranslating(true);
      const result = await translationAPI.translate(sourceText, targetLang, sourceLang);
      setTranslatedText(result);

      await translationHistoryAPI.create({
        source_text: sourceText,
        translated_text: result,
        source_language: sourceLang,
        target_language: targetLang
      });

      toast({
        title: 'Success',
        description: 'Translation completed successfully'
      });
    } catch (error: any) {
      toast({
        title: 'Translation Error',
        description: error.message || 'Failed to translate. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setIsTranslating(false);
    }
  };

  const handleSwapLanguages = () => {
    setSourceLang(targetLang);
    setTargetLang(sourceLang);
    setSourceText(translatedText);
    setTranslatedText(sourceText);
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: 'Copied',
      description: 'Text copied to clipboard'
    });
  };

  const handleSpeak = async (text: string) => {
    if (!text.trim()) {
      toast({
        title: 'Error',
        description: 'No text to speak',
        variant: 'destructive'
      });
      return;
    }

    try {
      setIsPlaying(true);
      const audioBlob = await textToSpeechAPI.convert(text);
      const audioUrl = URL.createObjectURL(audioBlob);
      
      if (audioRef.current) {
        audioRef.current.pause();
      }
      
      const audio = new Audio(audioUrl);
      audioRef.current = audio;
      
      audio.onended = () => {
        setIsPlaying(false);
        URL.revokeObjectURL(audioUrl);
      };
      
      await audio.play();
    } catch (error: any) {
      setIsPlaying(false);
      toast({
        title: 'Speech Error',
        description: error.message || 'Failed to play audio. Please try again.',
        variant: 'destructive'
      });
    }
  };

  const handleVoiceInput = async () => {
    try {
      setIsRecording(true);
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      const audioChunks: Blob[] = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunks.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        const audioFile = new File([audioBlob], 'recording.wav', { type: 'audio/wav' });
        
        try {
          const transcription = await speechToTextAPI.transcribe(audioFile);
          setSourceText(transcription);
          toast({
            title: 'Success',
            description: 'Voice input captured successfully'
          });
        } catch (error: any) {
          toast({
            title: 'Transcription Error',
            description: error.message || 'Failed to transcribe audio. Please try again.',
            variant: 'destructive'
          });
        } finally {
          setIsRecording(false);
        }
      };

      mediaRecorder.start();
      
      setTimeout(() => {
        mediaRecorder.stop();
        stream.getTracks().forEach(track => track.stop());
      }, 5000);

      toast({
        title: 'Recording',
        description: 'Speak now... (5 seconds)'
      });
    } catch (error) {
      setIsRecording(false);
      toast({
        title: 'Microphone Error',
        description: 'Failed to access microphone. Please check permissions.',
        variant: 'destructive'
      });
    }
  };

  const handlePhraseClick = (phrase: any) => {
    setSourceText(phrase.en);
    setSourceLang('en');
    setTargetLang('hi');
    setTranslatedText(phrase.hi);
  };

  return (
    <div className="min-h-screen bg-background pb-20 xl:pb-8">
      <div className="bg-info text-info-foreground py-8 px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">🗣️ Language Assistant</h1>
          <p className="opacity-90">Break language barriers with instant translation</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Languages className="w-5 h-5 mr-2" />
              Translator
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="text-sm font-medium mb-2 block">From</label>
                <Select value={sourceLang} onValueChange={setSourceLang}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {indianLanguages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code}>{lang.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">To</label>
                <Select value={targetLang} onValueChange={setTargetLang}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {indianLanguages.map(lang => (
                      <SelectItem key={lang.code} value={lang.code}>{lang.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 mb-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium">Source Text</label>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={handleVoiceInput}
                    disabled={isRecording}
                  >
                    <Mic className={`w-4 h-4 ${isRecording ? 'text-destructive' : ''}`} />
                  </Button>
                </div>
                <Textarea
                  placeholder="Enter text to translate..."
                  value={sourceText}
                  onChange={(e) => setSourceText(e.target.value)}
                  rows={6}
                  className="resize-none"
                />
                <div className="flex gap-2 mt-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleCopy(sourceText)}
                    disabled={!sourceText}
                  >
                    <Copy className="w-4 h-4 mr-1" />
                    Copy
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleSpeak(sourceText)}
                    disabled={!sourceText || isPlaying}
                  >
                    <Volume2 className="w-4 h-4 mr-1" />
                    Speak
                  </Button>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium">Translated Text</label>
                </div>
                <Textarea
                  placeholder="Translation will appear here..."
                  value={translatedText}
                  readOnly
                  rows={6}
                  className="resize-none bg-muted"
                />
                <div className="flex gap-2 mt-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleCopy(translatedText)}
                    disabled={!translatedText}
                  >
                    <Copy className="w-4 h-4 mr-1" />
                    Copy
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleSpeak(translatedText)}
                    disabled={!translatedText || isPlaying}
                  >
                    <Volume2 className="w-4 h-4 mr-1" />
                    Speak
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleTranslate}
                disabled={isTranslating || !sourceText}
                className="flex-1"
              >
                {isTranslating ? 'Translating...' : 'Translate'}
              </Button>
              <Button
                variant="outline"
                onClick={handleSwapLanguages}
              >
                <ArrowRightLeft className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-bold mb-4">📚 Common Phrases</h2>
            <p className="text-sm text-muted-foreground mb-4">
              Click on any phrase to use it in the translator
            </p>
          </div>

          {commonPhrases.map((category) => (
            <Card key={category.context}>
              <CardHeader>
                <CardTitle className="text-lg">{category.context}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {category.phrases.map((phrase, idx) => (
                    <div
                      key={idx}
                      onClick={() => handlePhraseClick(phrase)}
                      className="p-3 border border-border rounded-lg hover:bg-muted cursor-pointer transition-colors"
                    >
                      <p className="font-medium mb-1">{phrase.en}</p>
                      <p className="text-sm text-muted-foreground">{phrase.hi}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="mt-6 bg-gradient-primary text-primary-foreground">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold mb-2">💡 Language Tips</h3>
            <ul className="space-y-2 text-sm opacity-90">
              <li>• Use simple, clear sentences for better translations</li>
              <li>• Learn basic greetings in the local language</li>
              <li>• Don't hesitate to use gestures along with words</li>
              <li>• Save frequently used phrases for quick access</li>
              <li>• Practice pronunciation using the speak feature</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
