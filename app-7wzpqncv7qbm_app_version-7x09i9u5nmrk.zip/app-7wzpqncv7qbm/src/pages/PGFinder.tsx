import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { MapPin, Phone, Mail, Star, IndianRupee, Filter, List, Map as MapIcon, Sparkles } from 'lucide-react';
import { pgListingsAPI } from '@/services/database';
import type { PGListing, PGFilters } from '@/types/database';
import { useToast } from '@/hooks/use-toast';

export default function PGFinder() {
  const [listings, setListings] = useState<PGListing[]>([]);
  const [filteredListings, setFilteredListings] = useState<PGListing[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [showFilters, setShowFilters] = useState(false);
  const [cities, setCities] = useState<string[]>([]);
  const [states, setStates] = useState<string[]>([]);
  const { toast } = useToast();

  const [filters, setFilters] = useState<PGFilters>({
    city: '',
    state: '',
    priceMin: undefined,
    priceMax: undefined,
    genderPreference: undefined,
    hasAC: undefined,
    hasFood: undefined,
    searchQuery: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [listings, filters]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [listingsData, citiesData, statesData] = await Promise.all([
        pgListingsAPI.getAll(),
        pgListingsAPI.getCities(),
        pgListingsAPI.getStates()
      ]);
      setListings(listingsData);
      setCities(citiesData);
      setStates(statesData);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load PG listings. Please try again.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...listings];

    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      filtered = filtered.filter(pg =>
        pg.name.toLowerCase().includes(query) ||
        pg.description?.toLowerCase().includes(query) ||
        pg.address.toLowerCase().includes(query) ||
        pg.city.toLowerCase().includes(query)
      );
    }

    if (filters.city) {
      filtered = filtered.filter(pg => pg.city === filters.city);
    }

    if (filters.state) {
      filtered = filtered.filter(pg => pg.state === filters.state);
    }

    if (filters.priceMin !== undefined) {
      filtered = filtered.filter(pg => pg.price_max >= filters.priceMin!);
    }

    if (filters.priceMax !== undefined) {
      filtered = filtered.filter(pg => pg.price_min <= filters.priceMax!);
    }

    if (filters.genderPreference) {
      filtered = filtered.filter(pg =>
        pg.gender_preference === filters.genderPreference || pg.gender_preference === 'any'
      );
    }

    if (filters.hasAC !== undefined) {
      filtered = filtered.filter(pg => pg.has_ac === filters.hasAC);
    }

    if (filters.hasFood !== undefined) {
      filtered = filtered.filter(pg => pg.has_food === filters.hasFood);
    }

    setFilteredListings(filtered);
  };

  const calculateMatchScore = (pg: PGListing): number => {
    let score = pg.rating * 20;
    if (filters.hasAC && pg.has_ac) score += 10;
    if (filters.hasFood && pg.has_food) score += 10;
    return Math.min(Math.round(score), 100);
  };

  const resetFilters = () => {
    setFilters({
      city: '',
      state: '',
      priceMin: undefined,
      priceMax: undefined,
      genderPreference: undefined,
      hasAC: undefined,
      hasFood: undefined,
      searchQuery: ''
    });
  };

  return (
    <div className="min-h-screen bg-background pb-20 xl:pb-8">
      <div className="bg-primary text-primary-foreground py-8 px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">🏠 PG & Hostel Finder</h1>
          <p className="opacity-90">Find your perfect accommodation across India</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="mb-6 space-y-4">
          <div className="flex flex-col xl:flex-row gap-4">
            <Input
              placeholder="Search by name, location, or amenities..."
              value={filters.searchQuery}
              onChange={(e) => setFilters({ ...filters, searchQuery: e.target.value })}
              className="flex-1"
            />
            <div className="flex gap-2">
              <Button
                variant={showFilters ? 'default' : 'outline'}
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="w-4 h-4 mr-2" />
                Filters
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                onClick={() => setViewMode('list')}
              >
                <List className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'map' ? 'default' : 'outline'}
                onClick={() => setViewMode('map')}
              >
                <MapIcon className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {showFilters && (
            <Card>
              <CardContent className="p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">State</label>
                    <Select value={filters.state} onValueChange={(value) => setFilters({ ...filters, state: value, city: '' })}>
                      <SelectTrigger>
                        <SelectValue placeholder="All States" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All States</SelectItem>
                        {states.map(state => (
                          <SelectItem key={state} value={state}>{state}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">City</label>
                    <Select value={filters.city} onValueChange={(value) => setFilters({ ...filters, city: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="All Cities" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Cities</SelectItem>
                        {cities.map(city => (
                          <SelectItem key={city} value={city}>{city}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Min Price</label>
                    <Input
                      type="number"
                      placeholder="Min"
                      value={filters.priceMin || ''}
                      onChange={(e) => setFilters({ ...filters, priceMin: e.target.value ? Number(e.target.value) : undefined })}
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Max Price</label>
                    <Input
                      type="number"
                      placeholder="Max"
                      value={filters.priceMax || ''}
                      onChange={(e) => setFilters({ ...filters, priceMax: e.target.value ? Number(e.target.value) : undefined })}
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Gender Preference</label>
                    <Select value={filters.genderPreference} onValueChange={(value: any) => setFilters({ ...filters, genderPreference: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Any" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="any">Any</SelectItem>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">AC Required</label>
                    <Select value={filters.hasAC?.toString()} onValueChange={(value) => setFilters({ ...filters, hasAC: value === 'true' ? true : value === 'false' ? false : undefined })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Any" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="any">Any</SelectItem>
                        <SelectItem value="true">Yes</SelectItem>
                        <SelectItem value="false">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Food Included</label>
                    <Select value={filters.hasFood?.toString()} onValueChange={(value) => setFilters({ ...filters, hasFood: value === 'true' ? true : value === 'false' ? false : undefined })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Any" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="any">Any</SelectItem>
                        <SelectItem value="true">Yes</SelectItem>
                        <SelectItem value="false">No</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-end">
                    <Button variant="outline" onClick={resetFilters} className="w-full">
                      Reset Filters
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Found {filteredListings.length} PG{filteredListings.length !== 1 ? 's' : ''}
          </p>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <Skeleton className="h-48 w-full mb-4 bg-muted" />
                  <Skeleton className="h-6 w-3/4 mb-2 bg-muted" />
                  <Skeleton className="h-4 w-full mb-2 bg-muted" />
                  <Skeleton className="h-4 w-2/3 bg-muted" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : viewMode === 'list' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredListings.map((pg) => {
              const matchScore = calculateMatchScore(pg);
              return (
                <Card key={pg.id} className="hover:shadow-lg transition-all duration-300">
                  <CardContent className="p-0">
                    {pg.photos && pg.photos.length > 0 && (
                      <div className="relative h-48 overflow-hidden rounded-t-lg">
                        <img
                          src={pg.photos[0]}
                          alt={pg.name}
                          className="w-full h-full object-cover"
                        />
                        {matchScore >= 70 && (
                          <div className="absolute top-2 right-2 bg-primary text-primary-foreground px-2 py-1 rounded-full text-xs font-semibold flex items-center">
                            <Sparkles className="w-3 h-3 mr-1" />
                            {matchScore}% Match
                          </div>
                        )}
                      </div>
                    )}
                    <div className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-lg">{pg.name}</h3>
                        <div className="flex items-center text-sm">
                          <Star className="w-4 h-4 text-accent fill-accent mr-1" />
                          <span>{pg.rating.toFixed(1)}</span>
                        </div>
                      </div>

                      <div className="flex items-center text-sm text-muted-foreground mb-2">
                        <MapPin className="w-4 h-4 mr-1" />
                        <span>{pg.city}, {pg.state}</span>
                      </div>

                      <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                        {pg.description}
                      </p>

                      <div className="flex items-center text-primary font-semibold mb-3">
                        <IndianRupee className="w-4 h-4" />
                        <span>{pg.price_min.toLocaleString()} - {pg.price_max.toLocaleString()}/month</span>
                      </div>

                      <div className="flex flex-wrap gap-2 mb-3">
                        {pg.has_ac && <Badge variant="secondary">AC</Badge>}
                        {pg.has_food && <Badge variant="secondary">Food</Badge>}
                        {pg.gender_preference && (
                          <Badge variant="outline">{pg.gender_preference}</Badge>
                        )}
                      </div>

                      {pg.amenities && pg.amenities.length > 0 && (
                        <div className="flex flex-wrap gap-1 mb-3">
                          {pg.amenities.slice(0, 3).map((amenity, idx) => (
                            <span key={idx} className="text-xs bg-muted px-2 py-1 rounded">
                              {amenity}
                            </span>
                          ))}
                          {pg.amenities.length > 3 && (
                            <span className="text-xs text-muted-foreground px-2 py-1">
                              +{pg.amenities.length - 3} more
                            </span>
                          )}
                        </div>
                      )}

                      <div className="flex gap-2">
                        {pg.contact_phone && (
                          <Button size="sm" variant="outline" className="flex-1" asChild>
                            <a href={`tel:${pg.contact_phone}`}>
                              <Phone className="w-4 h-4 mr-1" />
                              Call
                            </a>
                          </Button>
                        )}
                        {pg.contact_email && (
                          <Button size="sm" variant="outline" className="flex-1" asChild>
                            <a href={`mailto:${pg.contact_email}`}>
                              <Mail className="w-4 h-4 mr-1" />
                              Email
                            </a>
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Map View</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-96 bg-muted rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <MapIcon className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">
                    Map view coming soon! 🗺️
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">
                    We're working on integrating interactive maps
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {!loading && filteredListings.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <p className="text-muted-foreground mb-4">No PGs found matching your criteria</p>
              <Button onClick={resetFilters}>Clear Filters</Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
