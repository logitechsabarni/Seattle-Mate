import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { User, MapPin, Briefcase, Settings, Heart, MessageSquare, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Profile() {
  return (
    <div className="min-h-screen bg-background pb-20 xl:pb-8">
      <div className="bg-primary text-primary-foreground py-8 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="w-20 h-20 rounded-full bg-primary-foreground/20 flex items-center justify-center mx-auto mb-4">
            <User className="w-10 h-10" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Welcome, Guest!</h1>
          <p className="opacity-90">Manage your profile and preferences</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Profile Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                <div className="flex items-center">
                  <User className="w-5 h-5 mr-3 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Full Name</p>
                    <p className="text-sm text-muted-foreground">Not set</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">Edit</Button>
              </div>

              <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                <div className="flex items-center">
                  <MapPin className="w-5 h-5 mr-3 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Current City</p>
                    <p className="text-sm text-muted-foreground">Not set</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">Edit</Button>
              </div>

              <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                <div className="flex items-center">
                  <Briefcase className="w-5 h-5 mr-3 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Profession Type</p>
                    <p className="text-sm text-muted-foreground">Not set</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">Edit</Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <Link to="/pgs">
            <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-lg bg-primary/10 text-primary mr-4">
                    <Heart className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-semibold">Saved PGs</p>
                    <p className="text-sm text-muted-foreground">0 saved</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link to="/community">
            <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-lg bg-secondary/10 text-secondary mr-4">
                    <MessageSquare className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-semibold">My Posts</p>
                    <p className="text-sm text-muted-foreground">0 posts</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link to="/safety">
            <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer">
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="p-3 rounded-lg bg-warning/10 text-warning mr-4">
                    <Shield className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-semibold">Emergency Contacts</p>
                    <p className="text-sm text-muted-foreground">Manage contacts</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-lg bg-accent/10 text-accent mr-4">
                  <Settings className="w-6 h-6" />
                </div>
                <div>
                  <p className="font-semibold">Settings</p>
                  <p className="text-sm text-muted-foreground">App preferences</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-gradient-primary text-primary-foreground">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold mb-2">🎯 Complete Your Profile</h3>
            <p className="text-sm opacity-90 mb-4">
              Add your details to get personalized recommendations and connect with the community
            </p>
            <Button variant="secondary">
              Complete Profile
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
