import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertCircle, Phone, Plus, Trash2, MapPin, Shield, AlertTriangle } from 'lucide-react';
import { emergencyContactsAPI } from '@/services/database';
import type { EmergencyContact } from '@/types/database';
import { useToast } from '@/hooks/use-toast';

export default function Safety() {
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [sosActive, setSosActive] = useState(false);
  const { toast } = useToast();

  const [newContact, setNewContact] = useState({
    name: '',
    phone: '',
    relationship: ''
  });

  const userId = 'demo-user-id';

  useEffect(() => {
    loadContacts();
  }, []);

  const loadContacts = async () => {
    try {
      const data = await emergencyContactsAPI.getByUserId(userId);
      setContacts(data);
    } catch (error) {
      console.error('Failed to load contacts:', error);
    }
  };

  const handleAddContact = async () => {
    if (!newContact.name || !newContact.phone) {
      toast({
        title: 'Error',
        description: 'Please fill in name and phone number',
        variant: 'destructive'
      });
      return;
    }

    try {
      await emergencyContactsAPI.create({
        user_id: userId,
        ...newContact
      });
      toast({
        title: 'Success',
        description: 'Emergency contact added successfully'
      });
      setIsDialogOpen(false);
      setNewContact({ name: '', phone: '', relationship: '' });
      loadContacts();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to add contact. Please try again.',
        variant: 'destructive'
      });
    }
  };

  const handleDeleteContact = async (id: string) => {
    try {
      await emergencyContactsAPI.delete(id);
      toast({
        title: 'Success',
        description: 'Contact deleted successfully'
      });
      loadContacts();
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete contact. Please try again.',
        variant: 'destructive'
      });
    }
  };

  const handleSOS = () => {
    setSosActive(true);
    toast({
      title: 'SOS Activated',
      description: 'Emergency contacts will be notified',
      variant: 'destructive'
    });

    setTimeout(() => {
      setSosActive(false);
    }, 5000);
  };

  const emergencyNumbers = [
    { name: 'Police', number: '100', icon: Shield },
    { name: 'Ambulance', number: '108', icon: AlertCircle },
    { name: 'Fire', number: '101', icon: AlertTriangle },
    { name: 'Women Helpline', number: '1091', icon: Phone },
    { name: 'Child Helpline', number: '1098', icon: Phone },
    { name: 'Disaster Management', number: '108', icon: AlertTriangle }
  ];

  const safetyTips = [
    'Always share your location with trusted contacts when traveling alone',
    'Keep emergency numbers saved in your phone',
    'Trust your instincts - if something feels wrong, leave immediately',
    'Avoid isolated areas, especially at night',
    'Keep your phone charged and have a power bank',
    'Learn basic self-defense techniques',
    'Stay aware of your surroundings at all times',
    'Use well-lit and populated routes'
  ];

  return (
    <div className="min-h-screen bg-background pb-20 xl:pb-8">
      <div className="bg-warning text-warning-foreground py-8 px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">🛡️ Safety Tools</h1>
          <p className="opacity-90">Stay safe with emergency features and resources</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        <Card className={`mb-6 ${sosActive ? 'border-destructive border-2' : ''}`}>
          <CardContent className="p-6">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4">Emergency SOS</h2>
              <p className="text-muted-foreground mb-6">
                Press and hold the button below in case of emergency
              </p>
              <Button
                size="lg"
                variant={sosActive ? 'default' : 'destructive'}
                className="w-48 h-48 rounded-full text-2xl font-bold"
                onClick={handleSOS}
                disabled={sosActive}
              >
                {sosActive ? 'ACTIVATED' : 'SOS'}
              </Button>
              <p className="text-sm text-muted-foreground mt-4">
                This will notify your emergency contacts and share your location
              </p>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Emergency Contacts</CardTitle>
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Emergency Contact</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">Name *</label>
                        <Input
                          placeholder="Enter name"
                          value={newContact.name}
                          onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">Phone *</label>
                        <Input
                          placeholder="Enter phone number"
                          value={newContact.phone}
                          onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium mb-2 block">Relationship</label>
                        <Input
                          placeholder="e.g., Parent, Friend, Sibling"
                          value={newContact.relationship}
                          onChange={(e) => setNewContact({ ...newContact, relationship: e.target.value })}
                        />
                      </div>
                      <Button onClick={handleAddContact} className="w-full">
                        Add Contact
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              {contacts.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No emergency contacts added yet</p>
                  <p className="text-sm mt-2">Add contacts to notify in emergencies</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {contacts.map((contact) => (
                    <div key={contact.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                      <div className="flex-1">
                        <p className="font-semibold">{contact.name}</p>
                        <p className="text-sm text-muted-foreground">{contact.phone}</p>
                        {contact.relationship && (
                          <p className="text-xs text-muted-foreground">{contact.relationship}</p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" asChild>
                          <a href={`tel:${contact.phone}`}>
                            <Phone className="w-4 h-4" />
                          </a>
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleDeleteContact(contact.id)}
                        >
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>National Emergency Numbers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {emergencyNumbers.map((item) => {
                  const Icon = item.icon;
                  return (
                    <Button
                      key={item.name}
                      variant="outline"
                      className="h-auto p-4 flex flex-col items-start"
                      asChild
                    >
                      <a href={`tel:${item.number}`}>
                        <div className="flex items-center mb-2">
                          <Icon className="w-5 h-5 mr-2 text-destructive" />
                          <span className="font-semibold">{item.name}</span>
                        </div>
                        <span className="text-2xl font-bold text-primary">{item.number}</span>
                      </a>
                    </Button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle>📍 Location Sharing</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">
              Share your real-time location with trusted contacts for added safety
            </p>
            <div className="flex gap-4">
              <Button className="flex-1">
                <MapPin className="w-4 h-4 mr-2" />
                Share Location
              </Button>
              <Button variant="outline" className="flex-1">
                View Shared Locations
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>💡 Safety Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {safetyTips.map((tip, idx) => (
                <li key={idx} className="flex items-start">
                  <span className="text-primary mr-2">•</span>
                  <span className="text-sm">{tip}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="mt-6 bg-gradient-primary text-primary-foreground">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold mb-2">🚨 Remember</h3>
            <p className="text-sm opacity-90">
              Your safety is paramount. Don't hesitate to call emergency services or reach out to your contacts if you feel unsafe. It's always better to be cautious than sorry.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
