import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Bus, Train, Car, Bike, Clock, IndianRupee, Navigation } from 'lucide-react';

interface RouteOption {
  mode: string;
  icon: any;
  duration: string;
  cost: string;
  description: string;
  color: string;
}

export default function TransportGuide() {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [showRoutes, setShowRoutes] = useState(false);

  const routeOptions: RouteOption[] = [
    {
      mode: 'Metro',
      icon: Train,
      duration: '25 mins',
      cost: '₹30-50',
      description: 'Fastest and most reliable option during peak hours',
      color: 'text-primary'
    },
    {
      mode: 'Bus',
      icon: Bus,
      duration: '40 mins',
      cost: '₹15-25',
      description: 'Most economical option with frequent services',
      color: 'text-secondary'
    },
    {
      mode: 'Auto',
      icon: Car,
      duration: '30 mins',
      cost: '₹80-120',
      description: 'Door-to-door service, good for short distances',
      color: 'text-accent'
    },
    {
      mode: 'Cab',
      icon: Car,
      duration: '25 mins',
      cost: '₹150-200',
      description: 'Comfortable and convenient, AC available',
      color: 'text-info'
    },
    {
      mode: 'Bike Rental',
      icon: Bike,
      duration: '20 mins',
      cost: '₹10-20',
      description: 'Flexible and fun, avoid traffic easily',
      color: 'text-success'
    }
  ];

  const handleSearch = () => {
    if (from && to) {
      setShowRoutes(true);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20 xl:pb-8">
      <div className="bg-accent text-accent-foreground py-8 px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">🚌 Transport Guide</h1>
          <p className="opacity-90">Navigate your city with ease and confidence</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Plan Your Route</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">From</label>
                <Input
                  placeholder="Enter starting location"
                  value={from}
                  onChange={(e) => setFrom(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-2 block">To</label>
                <Input
                  placeholder="Enter destination"
                  value={to}
                  onChange={(e) => setTo(e.target.value)}
                />
              </div>
              <Button onClick={handleSearch} className="w-full" disabled={!from || !to}>
                <Navigation className="w-4 h-4 mr-2" />
                Find Routes
              </Button>
            </div>
          </CardContent>
        </Card>

        {showRoutes && (
          <>
            <div className="mb-4">
              <h2 className="text-xl font-bold mb-2">Available Routes</h2>
              <p className="text-sm text-muted-foreground">
                From <span className="font-semibold">{from}</span> to <span className="font-semibold">{to}</span>
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 mb-6">
              {routeOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <Card key={option.mode} className="hover:shadow-lg transition-all duration-300">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          <div className={`p-3 rounded-lg bg-muted ${option.color}`}>
                            <Icon className="w-6 h-6" />
                          </div>
                          <h3 className="font-semibold text-lg ml-3">{option.mode}</h3>
                        </div>
                        <Badge variant="secondary">Recommended</Badge>
                      </div>

                      <div className="space-y-3 mb-4">
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center text-muted-foreground">
                            <Clock className="w-4 h-4 mr-2" />
                            <span>Duration</span>
                          </div>
                          <span className="font-semibold">{option.duration}</span>
                        </div>
                        <div className="flex items-center justify-between text-sm">
                          <div className="flex items-center text-muted-foreground">
                            <IndianRupee className="w-4 h-4 mr-2" />
                            <span>Estimated Cost</span>
                          </div>
                          <span className="font-semibold">{option.cost}</span>
                        </div>
                      </div>

                      <p className="text-sm text-muted-foreground mb-4">
                        {option.description}
                      </p>

                      <Button variant="outline" className="w-full">
                        View Details
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>🚇 Metro Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Buy a smart card for frequent travel to save money</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Avoid peak hours (8-10 AM, 6-8 PM) if possible</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>First and last coach are usually less crowded</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Download the official metro app for real-time updates</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>🚌 Bus Travel Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Keep exact change ready for faster boarding</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Use bus tracking apps to know arrival times</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>AC buses cost more but are more comfortable</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Ask locals or conductor if unsure about routes</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>🚗 Auto/Cab Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Always insist on meter or use ride-hailing apps</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Share your ride details with friends/family</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Keep small denominations for payment</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Check driver ratings before booking</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>🚲 Bike Rental Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Always wear a helmet for safety</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Check bike condition before starting</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Park only in designated areas</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-2">•</span>
                  <span>Keep your phone charged for navigation</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6 bg-gradient-primary text-primary-foreground">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold mb-2">🚨 Emergency Transport</h3>
            <p className="text-sm opacity-90 mb-4">
              In case of emergencies, these services are available 24/7:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-card/10 p-3 rounded-lg">
                <p className="font-semibold mb-1">Ambulance</p>
                <p className="text-sm">Call 108</p>
              </div>
              <div className="bg-card/10 p-3 rounded-lg">
                <p className="font-semibold mb-1">Police</p>
                <p className="text-sm">Call 100</p>
              </div>
              <div className="bg-card/10 p-3 rounded-lg">
                <p className="font-semibold mb-1">Women Helpline</p>
                <p className="text-sm">Call 1091</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
