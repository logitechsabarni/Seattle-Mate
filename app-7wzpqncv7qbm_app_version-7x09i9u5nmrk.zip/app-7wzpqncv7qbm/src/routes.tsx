import Home from './pages/Home';
import PGFinder from './pages/PGFinder';
import FoodServices from './pages/FoodServices';
import TransportGuide from './pages/TransportGuide';
import LanguageAssistant from './pages/LanguageAssistant';
import Community from './pages/Community';
import Safety from './pages/Safety';
import AIChat from './pages/AIChat';
import Profile from './pages/Profile';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <Home />
  },
  {
    name: 'PG Finder',
    path: '/pgs',
    element: <PGFinder />
  },
  {
    name: 'Food Services',
    path: '/food',
    element: <FoodServices />
  },
  {
    name: 'Transport Guide',
    path: '/transport',
    element: <TransportGuide />
  },
  {
    name: 'Language Assistant',
    path: '/language',
    element: <LanguageAssistant />
  },
  {
    name: 'Community',
    path: '/community',
    element: <Community />
  },
  {
    name: 'Safety',
    path: '/safety',
    element: <Safety />
  },
  {
    name: 'AI Chat',
    path: '/chat',
    element: <AIChat />
  },
  {
    name: 'Profile',
    path: '/profile',
    element: <Profile />
  }
];

export default routes;
