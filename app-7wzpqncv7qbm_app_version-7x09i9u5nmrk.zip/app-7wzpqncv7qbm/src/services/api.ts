const APP_ID = import.meta.env.VITE_APP_ID;

export const translationAPI = {
  async translate(text: string, targetLanguage: string, sourceLanguage?: string): Promise<string> {
    try {
      const payload: any = {
        q: text,
        target: targetLanguage,
        format: 'text'
      };

      if (sourceLanguage) {
        payload.source = sourceLanguage;
      }

      const response = await fetch(
        'https://api-integrations.appmedo.com/app-7wzpqncv7qbm/api-eLMl28BvNej9/language/translate/v2',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Translation API error:', errorText);
        throw new Error(`Translation failed: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error.message || 'Translation failed');
      }

      if (!data.data?.translations?.[0]?.translatedText) {
        throw new Error('Invalid response format from translation API');
      }

      return data.data.translations[0].translatedText;
    } catch (error: any) {
      console.error('Translation error:', error);
      throw new Error(error.message || 'Failed to translate text. Please try again.');
    }
  }
};

export const aiChatAPI = {
  async chat(messages: Array<{ role: 'user' | 'model'; content: string }>): Promise<string> {
    try {
      const contents = messages.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.content }]
      }));

      const response = await fetch(
        'https://api-integrations.appmedo.com/app-7wzpqncv7qbm/api-rLob8RdzAOl9/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-App-Id': APP_ID
          },
          body: JSON.stringify({ contents })
        }
      );

      if (!response.ok) {
        throw new Error('AI chat failed');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullResponse = '';

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const jsonData = JSON.parse(line.slice(6));
                const text = jsonData.candidates?.[0]?.content?.parts?.[0]?.text;
                if (text) {
                  fullResponse += text;
                }
              } catch (e) {
                console.error('Error parsing SSE data:', e);
              }
            }
          }
        }
      }

      return fullResponse || 'No response from AI';
    } catch (error) {
      console.error('AI chat error:', error);
      throw new Error('Failed to get AI response. Please try again.');
    }
  }
};

export const textToSpeechAPI = {
  async convert(text: string, voice = 'heart'): Promise<Blob> {
    try {
      const response = await fetch(
        'https://api-integrations.appmedo.com/app-7wzpqncv7qbm/api-wL1znZBlexBY/v1/audio/speech',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            input: text,
            voice: voice,
            response_format: 'mp3'
          })
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.error('TTS API error:', errorText);
        throw new Error(`Text-to-speech conversion failed: ${response.status}`);
      }

      return await response.blob();
    } catch (error: any) {
      console.error('TTS error:', error);
      throw new Error(error.message || 'Failed to convert text to speech. Please try again.');
    }
  }
};

export const speechToTextAPI = {
  async transcribe(audioFile: File | string): Promise<string> {
    try {
      const formData = new FormData();
      
      if (typeof audioFile === 'string') {
        formData.append('file', audioFile);
      } else {
        formData.append('file', audioFile);
      }
      
      formData.append('response_format', 'json');

      const response = await fetch(
        'https://api-integrations.appmedo.com/app-7wzpqncv7qbm/api-Xa6JZJO25zqa/v1/audio/transcriptions',
        {
          method: 'POST',
          body: formData
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        console.error('STT API error:', errorText);
        throw new Error(`Speech-to-text conversion failed: ${response.status}`);
      }

      const data = await response.json();
      
      if (!data.text) {
        throw new Error('Invalid response format from speech-to-text API');
      }

      return data.text;
    } catch (error: any) {
      console.error('STT error:', error);
      throw new Error(error.message || 'Failed to transcribe audio. Please try again.');
    }
  }
};
