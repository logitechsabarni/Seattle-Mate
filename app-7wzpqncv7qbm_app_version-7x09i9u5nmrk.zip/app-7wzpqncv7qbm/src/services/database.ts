import { supabase } from '@/db/supabase';
import type {
  PGListing,
  TiffinService,
  UserProfile,
  SavedPG,
  CommunityPost,
  PostComment,
  EmergencyContact,
  TranslationHistory,
  PGFilters
} from '@/types/database';

export const pgListingsAPI = {
  async getAll(filters?: PGFilters): Promise<PGListing[]> {
    let query = supabase.from('pg_listings').select('*').order('created_at', { ascending: false });

    if (filters?.city) {
      query = query.ilike('city', `%${filters.city}%`);
    }
    if (filters?.state) {
      query = query.ilike('state', `%${filters.state}%`);
    }
    if (filters?.priceMin !== undefined) {
      query = query.gte('price_min', filters.priceMin);
    }
    if (filters?.priceMax !== undefined) {
      query = query.lte('price_max', filters.priceMax);
    }
    if (filters?.genderPreference) {
      query = query.or(`gender_preference.eq.${filters.genderPreference},gender_preference.eq.any`);
    }
    if (filters?.hasAC !== undefined) {
      query = query.eq('has_ac', filters.hasAC);
    }
    if (filters?.hasFood !== undefined) {
      query = query.eq('has_food', filters.hasFood);
    }
    if (filters?.searchQuery) {
      query = query.or(`name.ilike.%${filters.searchQuery}%,description.ilike.%${filters.searchQuery}%,address.ilike.%${filters.searchQuery}%`);
    }

    const { data, error } = await query;
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getById(id: string): Promise<PGListing | null> {
    const { data, error } = await supabase
      .from('pg_listings')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async getCities(): Promise<string[]> {
    const { data, error } = await supabase
      .from('pg_listings')
      .select('city')
      .order('city', { ascending: true });
    if (error) throw error;
    const cities = Array.isArray(data) ? data.map(item => item.city) : [];
    return [...new Set(cities)];
  },

  async getStates(): Promise<string[]> {
    const { data, error } = await supabase
      .from('pg_listings')
      .select('state')
      .order('state', { ascending: true });
    if (error) throw error;
    const states = Array.isArray(data) ? data.map(item => item.state) : [];
    return [...new Set(states)];
  }
};

export const tiffinServicesAPI = {
  async getAll(city?: string): Promise<TiffinService[]> {
    let query = supabase.from('tiffin_services').select('*').order('rating', { ascending: false });
    
    if (city) {
      query = query.ilike('city', `%${city}%`);
    }

    const { data, error } = await query;
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getById(id: string): Promise<TiffinService | null> {
    const { data, error } = await supabase
      .from('tiffin_services')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    return data;
  }
};

export const userProfilesAPI = {
  async create(profile: Partial<UserProfile>): Promise<UserProfile> {
    const { data, error } = await supabase
      .from('user_profiles')
      .insert(profile)
      .select()
      .maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('Failed to create profile');
    return data;
  },

  async getById(id: string): Promise<UserProfile | null> {
    const { data, error } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async update(id: string, updates: Partial<UserProfile>): Promise<UserProfile> {
    const { data, error } = await supabase
      .from('user_profiles')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('Failed to update profile');
    return data;
  }
};

export const savedPGsAPI = {
  async getByUserId(userId: string): Promise<SavedPG[]> {
    const { data, error } = await supabase
      .from('saved_pgs')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async save(userId: string, pgId: string, notes?: string): Promise<SavedPG> {
    const { data, error } = await supabase
      .from('saved_pgs')
      .insert({ user_id: userId, pg_id: pgId, notes })
      .select()
      .maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('Failed to save PG');
    return data;
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase
      .from('saved_pgs')
      .delete()
      .eq('id', id);
    if (error) throw error;
  }
};

export const communityPostsAPI = {
  async getAll(city?: string, category?: string): Promise<CommunityPost[]> {
    let query = supabase.from('community_posts').select('*').order('created_at', { ascending: false });
    
    if (city) {
      query = query.eq('city', city);
    }
    if (category) {
      query = query.eq('category', category);
    }

    const { data, error } = await query;
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async getById(id: string): Promise<CommunityPost | null> {
    const { data, error } = await supabase
      .from('community_posts')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (error) throw error;
    return data;
  },

  async create(post: Partial<CommunityPost>): Promise<CommunityPost> {
    const { data, error } = await supabase
      .from('community_posts')
      .insert(post)
      .select()
      .maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('Failed to create post');
    return data;
  },

  async upvote(id: string): Promise<void> {
    const { data: post } = await supabase
      .from('community_posts')
      .select('upvotes')
      .eq('id', id)
      .maybeSingle();
    
    if (post) {
      const { error } = await supabase
        .from('community_posts')
        .update({ upvotes: (post.upvotes || 0) + 1 })
        .eq('id', id);
      if (error) throw error;
    }
  }
};

export const postCommentsAPI = {
  async getByPostId(postId: string): Promise<PostComment[]> {
    const { data, error } = await supabase
      .from('post_comments')
      .select('*')
      .eq('post_id', postId)
      .order('created_at', { ascending: true });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(comment: Partial<PostComment>): Promise<PostComment> {
    const { data, error } = await supabase
      .from('post_comments')
      .insert(comment)
      .select()
      .maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('Failed to create comment');
    return data;
  }
};

export const emergencyContactsAPI = {
  async getByUserId(userId: string): Promise<EmergencyContact[]> {
    const { data, error } = await supabase
      .from('emergency_contacts')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(contact: Partial<EmergencyContact>): Promise<EmergencyContact> {
    const { data, error } = await supabase
      .from('emergency_contacts')
      .insert(contact)
      .select()
      .maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('Failed to create contact');
    return data;
  },

  async delete(id: string): Promise<void> {
    const { error } = await supabase
      .from('emergency_contacts')
      .delete()
      .eq('id', id);
    if (error) throw error;
  }
};

export const translationHistoryAPI = {
  async getRecent(userId?: string, limit = 10): Promise<TranslationHistory[]> {
    let query = supabase
      .from('translation_history')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (userId) {
      query = query.eq('user_id', userId);
    }

    const { data, error } = await query;
    if (error) throw error;
    return Array.isArray(data) ? data : [];
  },

  async create(translation: Partial<TranslationHistory>): Promise<TranslationHistory> {
    const { data, error } = await supabase
      .from('translation_history')
      .insert(translation)
      .select()
      .maybeSingle();
    if (error) throw error;
    if (!data) throw new Error('Failed to save translation');
    return data;
  }
};
