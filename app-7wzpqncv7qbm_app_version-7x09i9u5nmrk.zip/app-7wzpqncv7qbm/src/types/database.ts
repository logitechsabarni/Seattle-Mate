export interface PGListing {
  id: string;
  name: string;
  description: string | null;
  address: string;
  city: string;
  state: string;
  latitude: number | null;
  longitude: number | null;
  price_min: number;
  price_max: number;
  gender_preference: 'male' | 'female' | 'any' | null;
  has_ac: boolean;
  has_food: boolean;
  amenities: string[] | null;
  photos: string[] | null;
  contact_name: string | null;
  contact_phone: string | null;
  contact_email: string | null;
  rating: number;
  created_at: string;
  updated_at: string;
}

export interface TiffinService {
  id: string;
  name: string;
  description: string | null;
  city: string;
  state: string;
  cuisine_types: string[] | null;
  meal_types: string[] | null;
  price_per_meal: number | null;
  monthly_plan_price: number | null;
  is_available: boolean;
  contact_phone: string | null;
  rating: number;
  created_at: string;
}

export interface UserProfile {
  id: string;
  full_name: string | null;
  phone: string | null;
  city: string | null;
  state: string | null;
  profession_type: 'student' | 'professional' | 'job_seeker' | null;
  preferences: Record<string, any>;
  created_at: string;
}

export interface SavedPG {
  id: string;
  user_id: string;
  pg_id: string;
  notes: string | null;
  created_at: string;
}

export interface CommunityPost {
  id: string;
  user_id: string | null;
  city: string;
  title: string;
  content: string;
  category: 'roommate' | 'event' | 'query' | 'general' | null;
  is_anonymous: boolean;
  upvotes: number;
  created_at: string;
}

export interface PostComment {
  id: string;
  post_id: string;
  user_id: string | null;
  content: string;
  is_anonymous: boolean;
  created_at: string;
}

export interface EmergencyContact {
  id: string;
  user_id: string;
  name: string;
  phone: string;
  relationship: string | null;
  created_at: string;
}

export interface TranslationHistory {
  id: string;
  user_id: string | null;
  source_text: string;
  translated_text: string;
  source_language: string | null;
  target_language: string;
  context: string | null;
  created_at: string;
}

export interface PGFilters {
  city?: string;
  state?: string;
  priceMin?: number;
  priceMax?: number;
  genderPreference?: 'male' | 'female' | 'any';
  hasAC?: boolean;
  hasFood?: boolean;
  searchQuery?: string;
}

export interface AIRecommendation {
  pg: PGListing;
  matchScore: number;
  reasons: string[];
}
