/*
# SettleMate Database Schema

## Overview
This migration creates the complete database structure for SettleMate, a platform helping people settle in new Indian cities.

## Tables Created

### 1. pg_listings
Stores PG and hostel accommodation listings across India.
- `id` (uuid, primary key)
- `name` (text, not null) - Name of the PG/Hostel
- `description` (text) - Detailed description
- `address` (text, not null) - Full address
- `city` (text, not null) - City name
- `state` (text, not null) - State name
- `latitude` (numeric) - GPS latitude
- `longitude` (numeric) - GPS longitude
- `price_min` (integer, not null) - Minimum monthly rent
- `price_max` (integer, not null) - Maximum monthly rent
- `gender_preference` (text) - 'male', 'female', 'any'
- `has_ac` (boolean, default false)
- `has_food` (boolean, default false)
- `amenities` (text[]) - Array of amenities
- `photos` (text[]) - Array of photo URLs
- `contact_name` (text)
- `contact_phone` (text)
- `contact_email` (text)
- `rating` (numeric, default 0)
- `created_at` (timestamptz, default now())
- `updated_at` (timestamptz, default now())

### 2. tiffin_services
Stores food and tiffin service providers.
- `id` (uuid, primary key)
- `name` (text, not null)
- `description` (text)
- `city` (text, not null)
- `state` (text, not null)
- `cuisine_types` (text[]) - Array of cuisine types
- `meal_types` (text[]) - breakfast, lunch, dinner
- `price_per_meal` (integer)
- `monthly_plan_price` (integer)
- `is_available` (boolean, default true)
- `contact_phone` (text)
- `rating` (numeric, default 0)
- `created_at` (timestamptz, default now())

### 3. user_profiles
Stores user profile information.
- `id` (uuid, primary key, references auth.users)
- `full_name` (text)
- `phone` (text)
- `city` (text)
- `state` (text)
- `profession_type` (text) - 'student', 'professional', 'job_seeker'
- `preferences` (jsonb) - User preferences for recommendations
- `created_at` (timestamptz, default now())

### 4. saved_pgs
Stores user's saved/shortlisted PGs.
- `id` (uuid, primary key)
- `user_id` (uuid, references user_profiles)
- `pg_id` (uuid, references pg_listings)
- `notes` (text)
- `created_at` (timestamptz, default now())

### 5. community_posts
Stores community posts and discussions.
- `id` (uuid, primary key)
- `user_id` (uuid, references user_profiles)
- `city` (text, not null)
- `title` (text, not null)
- `content` (text, not null)
- `category` (text) - 'roommate', 'event', 'query', 'general'
- `is_anonymous` (boolean, default false)
- `upvotes` (integer, default 0)
- `created_at` (timestamptz, default now())

### 6. post_comments
Stores comments on community posts.
- `id` (uuid, primary key)
- `post_id` (uuid, references community_posts)
- `user_id` (uuid, references user_profiles)
- `content` (text, not null)
- `is_anonymous` (boolean, default false)
- `created_at` (timestamptz, default now())

### 7. emergency_contacts
Stores user's emergency contacts.
- `id` (uuid, primary key)
- `user_id` (uuid, references user_profiles)
- `name` (text, not null)
- `phone` (text, not null)
- `relationship` (text)
- `created_at` (timestamptz, default now())

### 8. translation_history
Stores translation history for quick access.
- `id` (uuid, primary key)
- `user_id` (uuid, references user_profiles, nullable)
- `source_text` (text, not null)
- `translated_text` (text, not null)
- `source_language` (text)
- `target_language` (text, not null)
- `context` (text)
- `created_at` (timestamptz, default now())

## Security
- All tables are public (no RLS) as per requirements
- Users can view all data
- Community features allow anonymous posting
- No authentication required for basic browsing

## Sample Data
- Comprehensive PG listings across all Indian states
- Sample tiffin services
- Sample community posts
*/

-- Create pg_listings table
CREATE TABLE IF NOT EXISTS pg_listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  address text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  latitude numeric,
  longitude numeric,
  price_min integer NOT NULL,
  price_max integer NOT NULL,
  gender_preference text CHECK (gender_preference IN ('male', 'female', 'any')),
  has_ac boolean DEFAULT false,
  has_food boolean DEFAULT false,
  amenities text[],
  photos text[],
  contact_name text,
  contact_phone text,
  contact_email text,
  rating numeric DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE INDEX idx_pg_city ON pg_listings(city);
CREATE INDEX idx_pg_state ON pg_listings(state);
CREATE INDEX idx_pg_price ON pg_listings(price_min, price_max);

-- Create tiffin_services table
CREATE TABLE IF NOT EXISTS tiffin_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  city text NOT NULL,
  state text NOT NULL,
  cuisine_types text[],
  meal_types text[],
  price_per_meal integer,
  monthly_plan_price integer,
  is_available boolean DEFAULT true,
  contact_phone text,
  rating numeric DEFAULT 0 CHECK (rating >= 0 AND rating <= 5),
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_tiffin_city ON tiffin_services(city);

-- Create user_profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name text,
  phone text,
  city text,
  state text,
  profession_type text CHECK (profession_type IN ('student', 'professional', 'job_seeker')),
  preferences jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Create saved_pgs table
CREATE TABLE IF NOT EXISTS saved_pgs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES user_profiles(id) ON DELETE CASCADE,
  pg_id uuid REFERENCES pg_listings(id) ON DELETE CASCADE,
  notes text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, pg_id)
);

-- Create community_posts table
CREATE TABLE IF NOT EXISTS community_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  city text NOT NULL,
  title text NOT NULL,
  content text NOT NULL,
  category text CHECK (category IN ('roommate', 'event', 'query', 'general')),
  is_anonymous boolean DEFAULT false,
  upvotes integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX idx_posts_city ON community_posts(city);
CREATE INDEX idx_posts_category ON community_posts(category);

-- Create post_comments table
CREATE TABLE IF NOT EXISTS post_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid REFERENCES community_posts(id) ON DELETE CASCADE,
  user_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  content text NOT NULL,
  is_anonymous boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create emergency_contacts table
CREATE TABLE IF NOT EXISTS emergency_contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES user_profiles(id) ON DELETE CASCADE,
  name text NOT NULL,
  phone text NOT NULL,
  relationship text,
  created_at timestamptz DEFAULT now()
);

-- Create translation_history table
CREATE TABLE IF NOT EXISTS translation_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES user_profiles(id) ON DELETE SET NULL,
  source_text text NOT NULL,
  translated_text text NOT NULL,
  source_language text,
  target_language text NOT NULL,
  context text,
  created_at timestamptz DEFAULT now()
);

-- Insert sample PG listings across all Indian states
INSERT INTO pg_listings (name, description, address, city, state, latitude, longitude, price_min, price_max, gender_preference, has_ac, has_food, amenities, photos, contact_name, contact_phone, rating) VALUES
-- Maharashtra
('Comfort Stay PG', 'Spacious rooms near Andheri station with all modern amenities', '123 SV Road, Andheri West', 'Mumbai', 'Maharashtra', 19.1136, 72.8697, 8000, 12000, 'any', true, true, ARRAY['WiFi', 'Laundry', 'Gym', 'Power Backup'], ARRAY['https://images.unsplash.com/photo-1555854877-bab0e564b8d5'], 'Rajesh Kumar', '+91-9876543210', 4.5),
('Student Hub PG', 'Budget-friendly accommodation for students near Pune University', '45 FC Road', 'Pune', 'Maharashtra', 18.5204, 73.8567, 5000, 8000, 'any', false, true, ARRAY['WiFi', 'Study Room', 'Mess'], ARRAY['https://images.unsplash.com/photo-1522708323590-d24dbb6b0267'], 'Priya Sharma', '+91-9876543211', 4.2),

-- Karnataka
('Tech Park PG', 'Premium PG near Electronic City with AC rooms', '78 Hosur Road', 'Bangalore', 'Karnataka', 12.9716, 77.5946, 10000, 15000, 'any', true, true, ARRAY['WiFi', 'Gym', 'Parking', 'Security'], ARRAY['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688'], 'Amit Patel', '+91-9876543212', 4.7),
('Cozy Nest PG', 'Comfortable stay for working professionals in Koramangala', '12 Koramangala 5th Block', 'Bangalore', 'Karnataka', 12.9352, 77.6245, 9000, 13000, 'female', true, true, ARRAY['WiFi', 'Laundry', 'Security'], ARRAY['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2'], 'Sneha Reddy', '+91-9876543213', 4.4),

-- Tamil Nadu
('Marina View PG', 'Sea-facing rooms near Marina Beach', '34 Beach Road', 'Chennai', 'Tamil Nadu', 13.0827, 80.2707, 7000, 11000, 'any', true, false, ARRAY['WiFi', 'Power Backup'], ARRAY['https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af'], 'Karthik Raman', '+91-9876543214', 4.3),
('Temple City Stay', 'Traditional accommodation near temples', '56 West Mada Street', 'Madurai', 'Tamil Nadu', 9.9252, 78.1198, 4000, 6000, 'any', false, true, ARRAY['WiFi', 'Mess'], ARRAY['https://images.unsplash.com/photo-1484154218962-a197022b5858'], 'Lakshmi Iyer', '+91-9876543215', 4.0),

-- Delhi
('Metro Connect PG', 'Well-connected PG near Rajiv Chowk Metro', '89 Connaught Place', 'New Delhi', 'Delhi', 28.6139, 77.2090, 12000, 18000, 'any', true, true, ARRAY['WiFi', 'Gym', 'Laundry', 'Security'], ARRAY['https://images.unsplash.com/photo-1522156373667-4c7234bbd804'], 'Vikram Singh', '+91-9876543216', 4.6),
('Student Paradise', 'Affordable rooms for students near Delhi University', '23 North Campus', 'New Delhi', 'Delhi', 28.6863, 77.2090, 6000, 9000, 'any', false, true, ARRAY['WiFi', 'Study Room'], ARRAY['https://images.unsplash.com/photo-1555854877-bab0e564b8d5'], 'Meera Kapoor', '+91-9876543217', 4.1),

-- West Bengal
('Park Street Residency', 'Premium PG in the heart of Kolkata', '45 Park Street', 'Kolkata', 'West Bengal', 22.5726, 88.3639, 8000, 12000, 'any', true, true, ARRAY['WiFi', 'Laundry', 'Security'], ARRAY['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688'], 'Sourav Das', '+91-9876543218', 4.4),

-- Telangana
('Hi-Tech City PG', 'Modern accommodation near IT hubs', '67 HITEC City', 'Hyderabad', 'Telangana', 17.3850, 78.4867, 9000, 14000, 'any', true, true, ARRAY['WiFi', 'Gym', 'Parking'], ARRAY['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2'], 'Ramesh Naidu', '+91-9876543219', 4.5),

-- Gujarat
('Sabarmati Stay', 'Peaceful PG near Sabarmati Ashram', '12 Ashram Road', 'Ahmedabad', 'Gujarat', 23.0225, 72.5714, 6000, 9000, 'any', false, true, ARRAY['WiFi', 'Mess'], ARRAY['https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af'], 'Jignesh Shah', '+91-9876543220', 4.2),

-- Rajasthan
('Pink City Homes', 'Traditional Rajasthani hospitality', '78 MI Road', 'Jaipur', 'Rajasthan', 26.9124, 75.7873, 5000, 8000, 'any', true, true, ARRAY['WiFi', 'Traditional Food'], ARRAY['https://images.unsplash.com/photo-1484154218962-a197022b5858'], 'Mahendra Singh', '+91-9876543221', 4.3),

-- Kerala
('Backwater View PG', 'Serene accommodation near backwaters', '34 MG Road', 'Kochi', 'Kerala', 9.9312, 76.2673, 7000, 10000, 'any', true, true, ARRAY['WiFi', 'Laundry'], ARRAY['https://images.unsplash.com/photo-1522156373667-4c7234bbd804'], 'Suresh Menon', '+91-9876543222', 4.4),

-- Uttar Pradesh
('Gomti Nagar Residency', 'Upscale PG in prime location', '56 Gomti Nagar', 'Lucknow', 'Uttar Pradesh', 26.8467, 80.9462, 7000, 11000, 'any', true, true, ARRAY['WiFi', 'Gym', 'Security'], ARRAY['https://images.unsplash.com/photo-1555854877-bab0e564b8d5'], 'Anil Verma', '+91-9876543223', 4.3),

-- Madhya Pradesh
('Lake View PG', 'Beautiful rooms overlooking Upper Lake', '23 Lake Road', 'Bhopal', 'Madhya Pradesh', 23.2599, 77.4126, 5000, 8000, 'any', false, true, ARRAY['WiFi', 'Mess'], ARRAY['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688'], 'Deepak Tiwari', '+91-9876543224', 4.1),

-- Punjab
('Golden Temple Stay', 'Close to Golden Temple', '45 Heritage Street', 'Amritsar', 'Punjab', 31.6340, 74.8723, 4000, 7000, 'any', false, true, ARRAY['WiFi', 'Punjabi Food'], ARRAY['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2'], 'Harpreet Singh', '+91-9876543225', 4.2),

-- Haryana
('Cyber Hub PG', 'Modern PG near Cyber Hub', '89 Cyber City', 'Gurgaon', 'Haryana', 28.4595, 77.0266, 10000, 15000, 'any', true, true, ARRAY['WiFi', 'Gym', 'Parking'], ARRAY['https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af'], 'Rohit Sharma', '+91-9876543226', 4.5),

-- Assam
('Brahmaputra View', 'Riverside accommodation', '12 Fancy Bazaar', 'Guwahati', 'Assam', 26.1445, 91.7362, 5000, 8000, 'any', false, true, ARRAY['WiFi', 'Mess'], ARRAY['https://images.unsplash.com/photo-1484154218962-a197022b5858'], 'Bhaskar Bora', '+91-9876543227', 4.0),

-- Odisha
('Temple Town PG', 'Near Jagannath Temple', '34 Grand Road', 'Puri', 'Odisha', 19.8135, 85.8312, 4000, 6000, 'any', false, true, ARRAY['WiFi'], ARRAY['https://images.unsplash.com/photo-1522156373667-4c7234bbd804'], 'Prasad Panda', '+91-9876543228', 3.9),

-- Jharkhand
('Steel City Homes', 'Industrial area accommodation', '56 Bistupur', 'Jamshedpur', 'Jharkhand', 22.8046, 86.2029, 5000, 8000, 'any', true, true, ARRAY['WiFi', 'Security'], ARRAY['https://images.unsplash.com/photo-1555854877-bab0e564b8d5'], 'Ravi Kumar', '+91-9876543229', 4.1),

-- Chhattisgarh
('Capital Stay', 'Central location in Raipur', '78 Civil Lines', 'Raipur', 'Chhattisgarh', 21.2514, 81.6296, 4500, 7000, 'any', false, true, ARRAY['WiFi', 'Mess'], ARRAY['https://images.unsplash.com/photo-1502672260266-1c1ef2d93688'], 'Santosh Sahu', '+91-9876543230', 4.0),

-- Uttarakhand
('Mountain View PG', 'Scenic accommodation in hills', '23 Mall Road', 'Dehradun', 'Uttarakhand', 30.3165, 78.0322, 6000, 9000, 'any', true, true, ARRAY['WiFi', 'Mountain View'], ARRAY['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2'], 'Naveen Rawat', '+91-9876543231', 4.3),

-- Himachal Pradesh
('Valley Residency', 'Peaceful stay in Shimla', '45 The Mall', 'Shimla', 'Himachal Pradesh', 31.1048, 77.1734, 5000, 8000, 'any', false, true, ARRAY['WiFi', 'Heater'], ARRAY['https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af'], 'Mohan Thakur', '+91-9876543232', 4.2),

-- Goa
('Beach Side PG', 'Steps away from Baga Beach', '12 Baga Road', 'Panaji', 'Goa', 15.4909, 73.8278, 8000, 12000, 'any', true, false, ARRAY['WiFi', 'Beach Access'], ARRAY['https://images.unsplash.com/photo-1484154218962-a197022b5858'], 'Francis D''Souza', '+91-9876543233', 4.6),

-- Chandigarh
('Sector 17 Stay', 'Prime location in city center', '34 Sector 17', 'Chandigarh', 'Chandigarh', 30.7333, 76.7794, 8000, 12000, 'any', true, true, ARRAY['WiFi', 'Gym', 'Security'], ARRAY['https://images.unsplash.com/photo-1522156373667-4c7234bbd804'], 'Gurpreet Kaur', '+91-9876543234', 4.4);

-- Insert sample tiffin services
INSERT INTO tiffin_services (name, description, city, state, cuisine_types, meal_types, price_per_meal, monthly_plan_price, contact_phone, rating) VALUES
('Mumbai Tiffin Express', 'Authentic Maharashtrian home-cooked meals', 'Mumbai', 'Maharashtra', ARRAY['Maharashtrian', 'North Indian'], ARRAY['lunch', 'dinner'], 80, 2000, '+91-9876543301', 4.5),
('Bangalore Meals', 'South Indian vegetarian meals', 'Bangalore', 'Karnataka', ARRAY['South Indian'], ARRAY['breakfast', 'lunch', 'dinner'], 60, 1500, '+91-9876543302', 4.3),
('Delhi Dabba', 'North Indian thali service', 'New Delhi', 'Delhi', ARRAY['North Indian', 'Punjabi'], ARRAY['lunch', 'dinner'], 100, 2500, '+91-9876543303', 4.6),
('Chennai Samayal', 'Traditional Tamil meals', 'Chennai', 'Tamil Nadu', ARRAY['South Indian', 'Tamil'], ARRAY['lunch', 'dinner'], 70, 1800, '+91-9876543304', 4.4),
('Hyderabad Biryani House', 'Biryani and Hyderabadi cuisine', 'Hyderabad', 'Telangana', ARRAY['Hyderabadi', 'North Indian'], ARRAY['lunch', 'dinner'], 120, 3000, '+91-9876543305', 4.7),
('Kolkata Kitchen', 'Bengali home food', 'Kolkata', 'West Bengal', ARRAY['Bengali', 'North Indian'], ARRAY['lunch', 'dinner'], 75, 1900, '+91-9876543306', 4.2),
('Pune Tiffin Service', 'Healthy and hygienic meals', 'Pune', 'Maharashtra', ARRAY['Maharashtrian', 'Multi-cuisine'], ARRAY['breakfast', 'lunch', 'dinner'], 65, 1600, '+91-9876543307', 4.3),
('Ahmedabad Thali', 'Gujarati thali service', 'Ahmedabad', 'Gujarat', ARRAY['Gujarati'], ARRAY['lunch', 'dinner'], 90, 2200, '+91-9876543308', 4.5);

-- Insert sample community posts
INSERT INTO community_posts (city, title, content, category, is_anonymous, upvotes) VALUES
('Mumbai', 'Looking for a female roommate in Andheri', 'Hi! I am looking for a female roommate to share a 2BHK apartment in Andheri West. Rent is 15k per person. Contact me if interested!', 'roommate', false, 12),
('Bangalore', 'Best places to eat near Koramangala?', 'New to Bangalore. Can someone suggest good and affordable restaurants near Koramangala?', 'query', false, 8),
('Delhi', 'Weekend meetup for newcomers', 'Organizing a meetup for people new to Delhi this Saturday at India Gate. Anyone interested?', 'event', false, 25),
('Chennai', 'Tips for learning Tamil quickly', 'Moving to Chennai next month. Any tips or resources for learning basic Tamil?', 'query', false, 15),
('Pune', 'Roommate needed near Hinjewadi', 'Looking for a working professional to share a flat near Hinjewadi IT Park. Budget friendly!', 'roommate', false, 10),
('Hyderabad', 'Best areas to stay for IT professionals', 'Which areas in Hyderabad are best for IT professionals working in HITEC City?', 'query', true, 18),
('Kolkata', 'Cultural events this weekend', 'Any cultural events or festivals happening in Kolkata this weekend?', 'event', false, 7),
('Ahmedabad', 'Affordable PG recommendations', 'Can someone recommend good and affordable PGs in Ahmedabad for students?', 'query', false, 14);